# Catalogs

Integrating the Apache XTable™ (Incubating) synced target tables to external catalogs requires an explicit registration. This guide will
walk you through the required steps.

In addition to the information in this guide, we recommend you following official guidelines from the respective
catalogs while working with different table formats.