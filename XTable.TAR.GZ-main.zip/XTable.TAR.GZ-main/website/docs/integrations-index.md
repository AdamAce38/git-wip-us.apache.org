# Integrations

This guide will serve as a reference to integrate Apache XTable™ (Incubating) synced tables to various
catalogs and query engines.

In addition to the information in this guide, we recommend you following official guidelines
from the respective catalogs and query engines while working with different table formats.