======================================================
Apache Axiom ${project.version} (${build_date})

http://ws.apache.org/axiom/
------------------------------------------------------

___________________
Documentation
===================
 
Documentation can be found within this release and in the main site.

___________________
Support
===================
 
Any problem with this release can be reported to Apache Web Services mailing lists. 
If you are sending an email to the mailing list make sure to add the [Axiom] prefix to the subject.

Mailing list subscription:

users-subscribe@ws.apache.org
dev-subscribe@ws.apache.org

Thank you for using Axiom!

The Apache Axiom Team.
