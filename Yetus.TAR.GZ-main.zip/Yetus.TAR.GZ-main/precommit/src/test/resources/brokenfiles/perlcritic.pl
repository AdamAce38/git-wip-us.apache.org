#!/usr/bin/env perl

while (<>) {
  print $_
}