SSL test data
===================

Testing client/server keystore, password is "testpass".
Testing client/server truststore, password is "testpass".
